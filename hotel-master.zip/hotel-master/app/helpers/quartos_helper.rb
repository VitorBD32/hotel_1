module QuartosHelper
end
