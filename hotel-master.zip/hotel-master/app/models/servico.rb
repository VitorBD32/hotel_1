class Servico < ApplicationRecord
end
