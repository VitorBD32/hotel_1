class Reserva < ApplicationRecord
end
