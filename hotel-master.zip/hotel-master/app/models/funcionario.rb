class Funcionario < ApplicationRecord
end
