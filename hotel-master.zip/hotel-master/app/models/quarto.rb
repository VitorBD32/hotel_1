class Quarto < ApplicationRecord
end
